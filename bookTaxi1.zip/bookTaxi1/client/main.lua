RegisterNetEvent('AdvanceNotification')
AddEventHandler('AdvanceNotification', function(msg, sender, subject, imgdict, img)

    BeginTextCommandThefeedPost("STRING")
    AddTextComponentSubstringPlayerName(msg)
    if imgdict ~= nil and img ~= nil then
        EndTextCommandThefeedPostMessagetext(imgdict, img, false, 1, sender, subject)
    else
        EndTextCommandThefeedPostMessagetext('CHAR_TAXI', 'CHAR_TAXI', false, 1, companyName, subject)
    end

end)

RegisterNetEvent('Notification')
AddEventHandler('Notification', function(msg)

    BeginTextCommandThefeedPost("STRING")
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)

end)

RegisterNetEvent('blip:setlocation')
AddEventHandler('blip:setlocation', function(loaction, name, lastBlip)

    if lastBlip ~= nil then
        RemoveBlip(lastBlip)
    end
    local newBlip = AddBlipForCoord(loaction.x, loaction.y, loaction.z)
    SetBlipSprite(newBlip, radar.id)
    SetBlipDisplay(newBlip, 2)
    SetBlipScale(newBlip, radar.scale)
    SetBlipColour(newBlip, radar.color)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(name)
    EndTextCommandSetBlipName(newBlip)
    SetBlipAsShortRange(newBlip, false)
    SetBlipRoute(newBlip, true)
    TriggerServerEvent('customerBlipData', name, newBlip)

end)

RegisterNetEvent('blip:remove')
AddEventHandler('blip:remove', function(blip)
    
    if blip ~= nil then
        RemoveBlip(blip)
    end

end)

RegisterNetEvent('notificationWithPic')
AddEventHandler('notificationWithPic', function(msg, targetPed, sender, subject)
    
    local ped = GetPlayerPed(GetPlayerFromServerId(targetPed))
    local pedImage = RegisterPedheadshot(ped)
    while not IsPedheadshotReady(pedImage) or not IsPedheadshotValid(pedImage) do
        Citizen.Wait(0)
    end
    local pedImageheadImage = GetPedheadshotTxdString(pedImage)
    local pedpedName = GetPlayerName(PlayerId())
    TriggerEvent('AdvanceNotification', msg, sender, subject, pedImageheadImage, pedImageheadImage)
    UnregisterPedheadshot(pedImage)

end)

RegisterCommand(requestCommandName, function(source, args)
    
    local loc = GetEntityCoords(GetPlayerPed(-1))
    local pedName = GetPlayerName(PlayerId())
    TriggerServerEvent('taxi:checkbook', loc, pedName)

end)

RegisterCommand(acceptCommandName, function(source, args)

    local pedName = GetPlayerName(PlayerId())
    TriggerServerEvent('approchCustomer', args[1], pedName)

end)

RegisterCommand(list, function(source, args)

    TriggerServerEvent('listAllBooking', args[1])

end)

RegisterCommand(cancelCommandName, function(source, args)

    TriggerServerEvent('cancelBooking', args[1])

end)