requestCommandName = 'booktaxi'
acceptCommandName = 'takeride'
list = 'bookingList'
cancelCommandName = 'cancelBooking'

jobName = 'taxi'

radar = {
    id = 162,
    scale = 1.0,
    color = 1,
}

requestTaxiTitle = 'Request for booking taxi'
requestTaxiMsg = 'Recive taxi booking from:~n~Name: ~g~%s ~w~~n~Contact No: ~g~%d ~w~~n~Booking No: ~g~%d'
companyName = 'Los Santos Taxi'
notifyNoEmployesAvaliable = 'Sorry Currently all our employes are busy'
idNotAvaliable = 'Booking Id is Not avaliable (or) Someone already take the ride'
comingForPickUp = '~g~%s ~w~take your call ~n~For contact driver~n~Contact No:~g~ %d'
rideAcceptMessage = 'Booking accept'
bookingCancelTitle = 'Booking Cancel'
listTitle = 'Booking List:'
bookingCancel = 'Your booking is cancelled by our employee named ~r~%s'