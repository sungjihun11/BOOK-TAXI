ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local customersData = {}
local bookingId = 0

RegisterServerEvent('taxi:checkbook')
AddEventHandler('taxi:checkbook', function(customerlocation, customerName)
	
	local src = source
	local employes = ESX.GetExtendedPlayers('job', jobName)
	local player = ESX.GetPlayerFromId(src)
	local phoneNo = player.get('phoneNumber')
	if customersData[customerName] == nil then
		customersData[customerName] = {}
	end
	if #employes > 0 then
		bookingId = bookingId + 1
		customersData[customerName]['id'] = bookingId
		customersData[customerName]['coords'] = customerlocation
		customersData[customerName]['src'] = src
		customersData[customerName]['taken'] = false
		for _, employe in pairs(employes) do
			TriggerClientEvent('notificationWithPic', employe.source, string.format(requestTaxiMsg, customerName, phoneNo, bookingId), src, customerName, requestTaxiTitle)
		end
	else
		TriggerClientEvent('AdvanceNotification', src, notifyNoEmployesAvaliable, companyName, notifyNoEmployesAvaliable)
	end
end)

RegisterServerEvent('customerBlipData')
AddEventHandler('customerBlipData', function(name, currentBlip)
	
	customersData[name]['blip'] = currentBlip

end)

RegisterServerEvent('approchCustomer')
AddEventHandler('approchCustomer', function(bookingId, driverName)
	
	local src = source
	local player = ESX.GetPlayerFromId(src)
	local job = player.job.name
	local phNo = MySQL.Sync.fetchAll('SELECT charinfo FROM users WHERE identifier = @identifier', {
		['@identifier'] = player.getIdentifier()
	})
	print(phNo["phone"])
	local idExist = false
	local name = nil
	if job == jobName then
		for keys, values in pairs(customersData) do
			for key, value in pairs(values) do
				if key == 'id' and value == tonumber(bookingId) and customersData[keys]['taken'] == false then
					idExist = true
					customersData[keys]['taken'] = true
					TriggerClientEvent('blip:setlocation', src, customersData[keys]['coords'], keys, customersData[keys]['blip'])
					name = keys
				end
				if idExist then
					break
				end
			end
			if idExist then
				break
			end
		end
		if not idExist then
			TriggerClientEvent('Notification', src, idNotAvaliable)
			return
		elseif idExist == true then
			TriggerClientEvent('notificationWithPic', customersData[name]['src'], string.format(comingForPickUp, driverName, phNo), src, companyName, rideAcceptMessage)
			while true do
				Wait(500)
				if #(customersData[name]['coords'] - GetEntityCoords(GetPlayerPed(src))) < 5 and customersData[name]['blip'] ~= nil then
					TriggerClientEvent('blip:remove', src, customersData[name]['blip'])
					customersData[name] = nil
					break
				end
			end
		end
	end
end)

RegisterServerEvent('listAllBooking')
AddEventHandler('listAllBooking', function()
	
	local src = source
	local player = ESX.GetPlayerFromId(src)
	local job = player.job.name
	local msg = ''
	if job == jobName then
		for keys, values in pairs(customersData) do
			msg = msg..'~g~~n~BookingId: ~r~'..customersData[keys]['id']..' ~g~Name: ~r~'..keys
		end
	end
	TriggerClientEvent('AdvanceNotification', src, msg, companyName, listTitle)

end)

RegisterServerEvent('cancelBooking')
AddEventHandler('cancelBooking', function(BookingId)
	
	local src = source
	local player = ESX.GetPlayerFromId(src)
	local job = player.job.name
	local name = player.name
	if job == jobName then
		if BookingId ~= nil then
			for keys, values in pairs(customersData) do
				for key, value in pairs(values) do
					if key == 'id' and value == tonumber(BookingId) then
						TriggerClientEvent('AdvanceNotification', customersData[keys]['src'], string.format(bookingCancel, name), companyName, bookingCancelTitle)
						customersData[keys] = nil
					end
				end
			end
		end
	end

end)